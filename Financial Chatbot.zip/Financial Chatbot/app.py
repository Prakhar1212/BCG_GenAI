from flask import Flask, render_template, request

app = Flask(__name__)

# Financial data (simplified for this example)
financial_data = {
    "Apple": {
        "FY2022": {"Revenue Growth (%)": "7.79%","Net Income Growth (%)":"5.41%","Assets Growth (%)":"0.49%","Liabilities Growth (%)":"4.92%","Cash Flow Growth (%)":"17.40%","Total stockholders equity Growth (%)":"-19.68%"},
        "FY2023": {"Revenue Growth (%)": "-2.80%","Net Income Growth (%)":"-2.81%","Assets Growth (%)":"-0.04%","Liabilities Growth (%)":"-3.85%","Cash Flow Growth (%)":"-9.50%","Total stockholders equity Growth (%)":"22.64%"}
    },
    "Microsoft": {
        "FY2022": {"Revenue Growth (%)": "17.95%","Net Income Growth (%)":"18.71%","Assets Growth (%)":"9.30%","Liabilities Growth (%)":"3.39%","Cash Flow Growth (%)":"16.02%","Total stockholders equity Growth (%)":"17.29%"},
        "FY2023": {"Revenue Growth (%)": "6.88%","Net Income Growth (%)":"-0.51%","Assets Growth (%)":"12.91%","Liabilities Growth (%)":"3.75%","Cash Flow Growth (%)":"-1.63%","Total stockholders equity Growth (%)":"23.82%"}
    },
    "Tesla": {
        "FY2022": {"Revenue Growth (%)": "51.35%","Net Income Growth (%)":"123.01%","Assets Growth (%)":"32.52%","Liabilities Growth (%)":"19.28%","Cash Flow Growth (%)":"28.06%","Total stockholders equity Growth (%)":"48.08%"},
        "FY2023": {"Revenue Growth (%)": "18.79%","Net Income Growth (%)":"18.96%","Assets Growth (%)":"29.48%","Liabilities Growth (%)":"18.02%","Cash Flow Growth (%)":"-9.97%","Total stockholders equity Growth (%)":"40.10%"}
    }
}

# Define a function to handle chatbot logic
def get_financial_data(company, year, metric):
    return financial_data.get(company, {}).get(year, {}).get(metric, "Data not available")

# Route to the home page where the form is located
@app.route('/')
def home():
    return render_template('index.html')

# Route to handle the form submission
@app.route('/result', methods=['POST'])
def result():
    company = request.form.get('company')
    year = request.form.get('year')
    metric = request.form.get('metric')
    result = get_financial_data(company, year, metric)
    return render_template('result.html', company=company, year=year, metric=metric, result=result)

if __name__ == "__main__":
    app.run(debug=True)
