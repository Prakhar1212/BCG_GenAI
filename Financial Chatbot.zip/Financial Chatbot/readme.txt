Documentation

Chatbot Overview:

The chatbot is designed to provide financial insights based on predefined queries. It interacts with users through a web interface, where users can select company names, fiscal years, and financial metrics to retrieve relevant data.

Features:

User Interface:

The chatbot interface features a blue theme with an ambient light background color.
A chatbot logo is displayed at the top, with a small heading “Made by: Prakhar Raj Agrawal” below it.


Interaction Flow:

Welcome Message: The chatbot greets the user and invites them to choose a company.
Company Selection: Users can select a company from the provided options.
Fiscal Year Selection: Users choose a fiscal year from the available options.
Financial Metric Selection: Users select a financial metric they are interested in.
Response Handling: The chatbot provides the requested financial data and asks if the user wants to check for another company.
Exit Option: If the user chooses not to check another company.


Predefined Queries:

Company Names: Apple, Microsoft, Tesla
Fiscal Years: FY2022, FY2023

Financial Metrics:
Revenue Growth (%)
Net Income Growth (%)
Assets Growth (%)
Liabilities Growth (%)
Cash Flow Growth (%)
Total Stockholders Equity Growth (%)


Limitations:

The chatbot currently handles a fixed set of companies, fiscal years, and financial metrics. It does not support dynamic or real-time data updates.
If the user inputs data not within the predefined options, the chatbot prompts them to enter data from the available options, but it does not handle more complex queries or natural language inputs beyond the predefined set.
The interface and functionality are designed for a simple interaction model and may not support advanced features like natural language processing or machine learning-based responses.
Conclusion:

This chatbot prototype demonstrates basic financial data querying capabilities and serves as a foundation for more advanced development. It effectively integrates predefined financial data into an interactive format, providing users with accessible and understandable financial insights.
